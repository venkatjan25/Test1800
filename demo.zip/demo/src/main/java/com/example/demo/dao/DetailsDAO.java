package com.example.demo.dao;

import com.example.demo.dto.Details;

import java.util.List;

public interface DetailsDAO {
    public List<Details> getDetails();
    public Details getUpdatedDetails();
}
