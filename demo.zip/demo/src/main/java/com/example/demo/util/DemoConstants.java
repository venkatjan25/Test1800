package com.example.demo.util;

public class DemoConstants {

    public static final String BASE_URI= "http://jsonplaceholder.typicode.com/posts";
    public static final String UPDATE_URI = "https://jsonplaceholder.typicode.com/posts/4";
}
